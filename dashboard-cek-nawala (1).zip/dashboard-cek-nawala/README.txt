DASHBOARD CEK NAWALA

Isi:
- index.html : tampilan dashboard
- api.php    : backend pemeriksaan domain
- composer.json : dependensi PHP

PENTING:
Dashboard ini membutuhkan hosting yang mendukung PHP 8.0+ dan Composer.
GitHub Pages dan Netlify static hosting tidak dapat menjalankan api.php secara langsung.

LANGKAH PEMASANGAN:
1. Siapkan hosting PHP 8.0+ dengan ekstensi cURL dan JSON.
2. Upload index.html, api.php, dan composer.json ke folder website.
3. Jalankan `composer install` di folder tersebut (melalui Terminal/SSH atau fitur Composer hosting).
4. Pastikan folder `vendor/` terbentuk di samping api.php.
5. Buka alamat website Anda. Masukkan domain satu per baris, lalu klik "Cek Semua Link".

SUMBER PEMERIKSAAN:
Library Hypernic Nawala menggunakan sumber TrustPositif Komdigi dan dapat terdampak perubahan endpoint, rate limit, atau gangguan layanan.
Repository: https://github.com/undip-if/nawala

CATATAN:
- Maksimal 100 domain per sekali pemeriksaan.
- Status SAFE berarti domain tidak ditemukan dalam daftar blokir pada saat pemeriksaan; bukan jaminan semua jaringan/ISP dapat mengaksesnya.
- ERROR berarti pemeriksaan gagal/tidak dapat dipastikan, bukan berarti domain aman atau diblokir.
- Jangan menganggap hasil dari contoh data atau tampilan sebagai hasil pemeriksaan nyata.
