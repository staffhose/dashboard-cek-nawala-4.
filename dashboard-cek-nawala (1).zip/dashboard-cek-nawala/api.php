<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Gunakan metode POST.']);
    exit;
}

require __DIR__ . '/vendor/autoload.php';

use Hypernic\Nawala;

try {
    $payload = json_decode(file_get_contents('php://input'), true, 512, JSON_THROW_ON_ERROR);
    $domains = $payload['domains'] ?? null;

    if (!is_array($domains) || count($domains) < 1 || count($domains) > 100) {
        throw new InvalidArgumentException('Kirim 1 sampai 100 domain.');
    }

    $checker = new Nawala([
        'timeout' => 12,
        'connect_timeout' => 6,
        'retries' => 1,
        'cache' => ['enabled' => true],
    ]);

    $results = [];
    foreach ($domains as $input) {
        $domain = strtolower(trim((string)$input));
        $domain = preg_replace('#^https?://#i', '', $domain);
        $domain = preg_replace('#/.*$#', '', $domain);
        $domain = preg_replace('/:\d+$/', '', $domain);
        $domain = rtrim($domain, '.');

        if ($domain === '' || strlen($domain) > 253 ||
            !preg_match('/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+$/i', $domain)) {
            $results[] = ['domain' => (string)$input, 'status' => 'ERROR', 'message' => 'Format domain tidak valid'];
            continue;
        }

        try {
            $result = $checker->check($domain);
            if (($result['status'] ?? false) !== true || !isset($result['data']['blocked'])) {
                $results[] = ['domain' => $domain, 'status' => 'ERROR', 'message' => $result['error'] ?? 'Respons pemeriksaan tidak dikenali'];
                continue;
            }
            $results[] = [
                'domain' => $domain,
                'status' => $result['data']['blocked'] ? 'BLOCKED' : 'SAFE',
                'checked_at' => date('Y-m-d H:i:s'),
            ];
        } catch (Throwable $e) {
            $results[] = ['domain' => $domain, 'status' => 'ERROR', 'message' => 'Pemeriksaan tidak berhasil'];
        }
    }

    echo json_encode(['ok' => true, 'results' => $results], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e instanceof InvalidArgumentException ? $e->getMessage() : 'Permintaan tidak dapat diproses.']);
}
